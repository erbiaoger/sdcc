#define PCF8591_ID 0x90

extern unsigned char ReadPCF8591(char address, char channel);
