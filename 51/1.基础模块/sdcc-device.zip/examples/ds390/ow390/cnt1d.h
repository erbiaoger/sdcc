extern int ReadCounter(int, uchar *SerialNum, int, unsigned long *);
