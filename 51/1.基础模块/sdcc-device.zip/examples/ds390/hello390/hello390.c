#include <stdio.h>

void main (void) {
  printf ("\nHello from 390.\nSee you, bye...");
}
