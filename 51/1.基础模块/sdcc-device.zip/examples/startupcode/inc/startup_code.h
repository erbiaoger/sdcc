// INCLUDES & DEFINES ===============================================
// here are some definition about the CPU type

#ifndef __FILE_WSI_128KFLASH_H
#define __FILE_WSI_128KFLASH_H

#include "..\inc\hardware_description.h"

// place all 8051-CPU depending tools ISR and functions here

//include "..\inc\another_header.h"
#endif